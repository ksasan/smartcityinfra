MainActivity, CameraActivity -> Two Main screens being used as of now (Main and Problem capturing screen)
SubmitReport -> Class handling submission logic to backend server
SingleShotLocationProvider -> Utility to get CURRENT Location (single time)
	=> Currently it is being programmed on periodic basis to get continuous updates
MultipartUtility -> Class providing logic for multi-part form submission to backend server's service
ScirInfraFeedbackPoint.java -> Entity representing SINGLE Grievance Data Point

CheckLocationActivity.java -> Not in use, but available from main screen's button to check location updates.
SCIRLocationFinder.java -> NOT BEING USED, to be cleaned off

